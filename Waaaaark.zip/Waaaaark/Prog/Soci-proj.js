const { cyan } = require("colorette");

cy.visit('http:google.com')