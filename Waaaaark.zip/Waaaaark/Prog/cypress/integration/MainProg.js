///<reference types="cypress"/>



// it("test", function(){
//     cy.visit('https://www.google.com/')
//     cy.get('.gLFyf').type('Arsenal').type('{enter}')
//     cy.get('.MUFPAc > :nth-child(5) > a').click()
    
// })


it("Login", function(){
    Cypress.on('uncaught:exception', (err, runnable) => {
        // returning false here prevents Cypress from
        // failing the test
        return false
    })
    cy.visit("https://sneaky.meetsoci.com/admin/")
    cy.get('#password_login > :nth-child(2) > .input_email').type("skakade@meetsoci.com")
    cy.get('.input_password').type("Logitech@2").type('{enter}')
    cy.wait(5000)
    cy.get('.select2-arrow', {timeout: 200} ).should('be.visible').click()
    cy.contains('Smoke-21').click()
    cy.wait(400)

})

it('loc', function(){
    
    cy.get('#nav_icon_right').click()
    cy.wait(5000)
    cy.get('.back_office').click()

})